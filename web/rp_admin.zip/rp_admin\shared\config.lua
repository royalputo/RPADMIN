RP_ADMIN = {
  url = "https://rpadmin.mtarg.xyz",
  serverKey = "rsk_03b05cee2d9b5d9a1878238989",
  serverId = "3",
  serverUuid = "srv-902",
  panelUrl = "https://rpadmin.mtarg.xyz",
  pollInterval = 3000,
  snapshotInterval = 20000,
  eventFlushInterval = 5000,
  logChat = true,
  showStatusLabel = true,
  debug = false,
}
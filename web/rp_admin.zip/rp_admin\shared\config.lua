-- RpAdmin connector — placeholder config.
-- Replace every value below (or copy shared/config.lua.example) before use.
-- See docs/install.md.

RP_ADMIN = {
  url = "",
  serverKey = "",
  serverId = "0",
  serverUuid = "",
  panelUrl = "https://rpadmin.mtarg.xyz",
  pollInterval = 3000,
  snapshotInterval = 20000,
  eventFlushInterval = 5000,
  logFile = "",
  logTailInterval = 5000,
  logChat = true,
  showStatusLabel = true,
  debug = false,
}

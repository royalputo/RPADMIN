--[[
  RpAdmin — Dev By Royalputo
  Outbound connector agent.

  Auth model: every request sends the server key in the X-Server-Key header.
  Supabase RLS matches sha256(key) against servers.key_hash, so no agent auth
  user, service-role key or Edge Function is required.

  IMPORTANT: MTA forbids calling fetchRemote from inside a fetchRemote callback.
  Every follow-up request is scheduled with setTimer (see later()).
]]

local CFG = RP_ADMIN or {}
local BASE = tostring(CFG.url or ""):gsub("/+$", "")
local STARTED = getRealTime().timestamp
local joinTimes = {}

local STATE = {
  enabled = false,
  online = false,
  lastSync = 0,
  lastError = nil,
  pollTimer = nil,
}
_G.RP_ADMIN_STATE = STATE

local function log(message)
  outputServerLog("[RpAdmin] " .. tostring(message))
end

local function dbg(message)
  if CFG.debug then
    outputDebugString("[RpAdmin] " .. tostring(message), 3)
  end
end

local function later(fn, delay)
  setTimer(fn, delay or 0, 1)
end

local function isoFrom(timestamp)
  return os.date("!%Y-%m-%dT%H:%M:%SZ", timestamp or getRealTime().timestamp)
end

local function isoNow()
  return isoFrom(getRealTime().timestamp)
end

local function filled(value)
  return type(value) == "string" and value ~= "" and not string.find(value, "<", 1, true)
end

local function configured()
  return BASE ~= ""
    and filled(CFG.serverKey)
    and filled(CFG.serverUuid)
end

local function decode(data)
  if type(data) ~= "string" or data == "" then return nil end
  local ok, value = pcall(fromJSON, data)
  if ok and type(value) == "table" then return value end
  return nil
end

-- ---------------------------------------------------------------
-- HTTP
-- ---------------------------------------------------------------

local function call(opts)
  if BASE == "" then return end

  local headers = {
    "Content-Type: application/json",
    "X-Server-Key: " .. tostring(CFG.serverKey),
    "Prefer: return=minimal",
  }

  local method = opts.method or "GET"
  local options = {
    method = method,
    headers = table.concat(headers, "\r\n"),
    connectionTimeout = 10000,
  }

  local postData = ""
  if opts.body ~= nil then
    local ok, encoded = pcall(toJSON, opts.body)
    if not ok then
      log("failed to encode request body")
      return
    end
    postData = encoded
  end

  -- This MTA build uses the legacy signature:
  -- fetchRemote(url, callback, postData, isPost, options).
  local isPost = method ~= "GET" and method ~= "HEAD"
  local started = fetchRemote(BASE .. "/api/rest" .. opts.path, function(data, errno, info)
    local status = 0
    if type(info) == "table" and tonumber(info.statusCode) then
      status = tonumber(info.statusCode)
    elseif errno == 0 then
      status = 200
    end
    opts.onDone(status, data or "", errno)
  end, postData, isPost, options)

  if not started then
    later(function() opts.onDone(0, "", -1) end)
  end
end

-- ---------------------------------------------------------------
-- Polling
-- ---------------------------------------------------------------

local poll

local function schedulePoll(delay)
  if not STATE.enabled then return end
  if STATE.pollTimer and isTimer(STATE.pollTimer) then
    killTimer(STATE.pollTimer)
  end
  STATE.pollTimer = setTimer(poll, delay or tonumber(CFG.pollInterval) or 3000, 1)
end

local function updateCommand(id, status, result, errorText, cb)
  call({
    method = "POST",
    path = "/rpc/agent_update_command",
    body = {
      p_server = CFG.serverUuid,
      p_id = id,
      p_status = status,
      p_result = result,
      p_error = errorText,
    },
    onDone = function(httpStatus)
      if httpStatus < 200 or httpStatus >= 300 then
        dbg("failed to update command " .. tostring(id) .. " (HTTP " .. tostring(httpStatus) .. ")")
      end
      if cb then cb() end
    end,
  })
end

local function utcEpoch(iso)
  if type(iso) ~= "string" then return nil end
  local y, m, d, h, mi, s = string.match(iso, "(%d+)%-(%d+)%-(%d+)T(%d+):(%d+):(%d+)")
  if not y then return nil end
  return os.time({
    year = tonumber(y), month = tonumber(m), day = tonumber(d),
    hour = tonumber(h), min = tonumber(mi), sec = tonumber(s), isdst = false,
  })
end

local function isExpired(cmd)
  local expires = utcEpoch(cmd.expires_at)
  if not expires then return false end
  return expires < os.time(os.date("!*t"))
end

local function processBatch(list, index)
  if index > #list then
    schedulePoll(CFG.pollInterval)
    return
  end
  local cmd = list[index]
  later(function()
    if isExpired(cmd) then
      updateCommand(cmd.id, "expired", nil, "Expired before the server polled", function()
        later(function() processBatch(list, index + 1) end)
      end)
      return
    end

    local ok, result, err = RPAdminExecute(cmd.action, cmd.args)
    dbg(string.format("command %s (%s) -> %s", tostring(cmd.id), tostring(cmd.action), ok and "done" or "failed"))

    updateCommand(cmd.id, ok and "done" or "failed", result, err and tostring(err) or nil, function()
      later(function() processBatch(list, index + 1) end)
    end)
  end)
end

local function fetchCommands()
  local path = "/commands?select=id,action,args,expires_at"
    .. "&server_id=eq." .. tostring(CFG.serverUuid)
    .. "&status=eq.pending&order=id.asc&limit=10"
  call({
    path = path,
    onDone = function(status, data)
      if status == 401 or status == 403 then
        STATE.online = false
        STATE.lastError = "key rejected (HTTP " .. tostring(status) .. ")"
        log("server key rejected (HTTP " .. tostring(status) .. ") — rotate the key or check shared/config.lua")
        later(function() schedulePoll(15000) end)
        return
      end
      if status == 404 then
        STATE.online = false
        STATE.lastError = "schema missing (HTTP 404)"
        log("Supabase schema not found — run supabase/migrations/0001_init.sql")
        later(function() schedulePoll(30000) end)
        return
      end
      if status < 200 or status >= 300 then
        STATE.online = false
        STATE.lastError = "poll HTTP " .. tostring(status)
        dbg("poll failed (HTTP " .. tostring(status) .. ")")
        later(function() schedulePoll(5000) end)
        return
      end
      STATE.online = true
      STATE.lastSync = getRealTime().timestamp
      STATE.lastError = nil
      local list = decode(data) or {}
      later(function() processBatch(list, 1) end)
    end,
  })
end

poll = function()
  if not STATE.enabled then return end
  fetchCommands()
end

-- ---------------------------------------------------------------
-- Snapshot
-- ---------------------------------------------------------------

local function countryOf(player)
  local ok, result = pcall(function()
    local res = getResourceFromName("ip2c")
    if res and getResourceState(res) == "running" then
      return exports.ip2c:getPlayerCountry(player)
    end
    return false
  end)
  if ok and result and result ~= false then return tostring(result) end
  return "Unknown"
end

local function accountName(player)
  local account = getPlayerAccount(player)
  if account and not isGuestAccount(account) then
    return getAccountName(account)
  end
  return "guest"
end

local function isStaffPlayer(player)
  local account = getPlayerAccount(player)
  if not account or isGuestAccount(account) then return false end
  local user = "user." .. getAccountName(account)
  for _, name in ipairs({ "Moderator", "SuperModerator", "Admin" }) do
    local group = aclGetGroup(name)
    if group and isObjectInACLGroup(user, group) then return true end
  end
  return false
end

local function safe(fn, fallback)
  local ok, value = pcall(fn)
  if ok and value ~= nil then return value end
  return fallback
end

local function buildSnapshot()
  local players = {}
  for _, player in ipairs(getElementsByType("player")) do
    local team = getPlayerTeam(player)
    players[#players + 1] = {
      name = getPlayerName(player),
      ping = safe(function() return getPlayerPing(player) end, 0),
      ip = safe(function() return getPlayerIP(player) end, ""),
      serial = safe(function() return getPlayerSerial(player) end, ""),
      country = countryOf(player),
      health = math.floor(safe(function() return getElementHealth(player) end, 0)),
      armor = math.floor(safe(function() return getPedArmor(player) end, 0)),
      team = team and getTeamName(team) or "-",
      muted = safe(function() return isPlayerMuted(player) end, false) and true or false,
      frozen = safe(function() return isElementFrozen(player) end, false) and true or false,
      admin = isStaffPlayer(player),
      account = accountName(player),
      joinedAt = isoFrom(joinTimes[player] or STARTED),
    }
  end

  local resources = {}
  for _, res in ipairs(getResources()) do
    resources[#resources + 1] = {
      name = getResourceName(res),
      state = getResourceState(res),
      type = safe(function() return getResourceInfo(res, "type") end, ""),
      author = safe(function() return getResourceInfo(res, "author") end, ""),
      version = safe(function() return getResourceInfo(res, "version") end, ""),
    }
  end
  table.sort(resources, function(a, b) return string.lower(a.name) < string.lower(b.name) end)

  local bans = {}
  for index, ban in ipairs(getBans()) do
    local unbanTime = safe(function() return getUnbanTime(ban) end, 0)
    bans[#bans + 1] = {
      id = "ban-" .. index,
      ip = safe(function() return getBanIP(ban) end, ""),
      serial = safe(function() return getBanSerial(ban) end, ""),
      nick = safe(function() return getBanNick(ban) end, ""),
      reason = safe(function() return getBanReason(ban) end, ""),
      bannedAt = isoNow(),
      unbanTime = unbanTime and unbanTime * 1000 or 0,
    }
  end

  local gamemode = safe(function()
    local res = getRunningGamemode()
    if res then return getResourceName(res) end
    return "-"
  end, "-")

  return {
    players = players,
    resources = resources,
    bans = bans,
    uptime = math.max(0, getRealTime().timestamp - STARTED),
    httpPort = safe(function() return getServerHttpPort() end, 0),
  }, gamemode
end

local function broadcastStatus()
  for _, player in ipairs(getElementsByType("player")) do
    if isStaffPlayer(player) then
      triggerClientEvent("rpAdmin:status", player, STATE.online, STATE.lastSync)
    end
  end
end

local function pushSnapshot()
  if not STATE.enabled then return end
  local snapshot, gamemode = buildSnapshot()
  call({
    method = "POST",
    path = "/rpc/agent_update_state",
    body = {
      p_server = CFG.serverUuid,
      p_last_seen = isoNow(),
      p_snapshot = snapshot,
      p_version = getVersion(),
      p_gamemode = gamemode,
      p_maxplayers = getMaxPlayers(),
      p_port = getServerPort(),
      p_player_count = getPlayerCount(),
    },
    onDone = function(status)
      if status >= 200 and status < 300 then
        STATE.online = true
        STATE.lastSync = getRealTime().timestamp
      else
        STATE.online = false
        dbg("snapshot failed (HTTP " .. tostring(status) .. ")")
      end
      broadcastStatus()
    end,
  })
end

local snapshotPending = false
function rpAdminQueueSnapshot(delay)
  if not STATE.enabled or snapshotPending then return end
  snapshotPending = true
  setTimer(function()
    snapshotPending = false
    pushSnapshot()
  end, delay or 1500, 1)
end

-- ---------------------------------------------------------------
-- Activity
-- ---------------------------------------------------------------

local eventQueue = {}

function rpAdminPushActivity(kind, actor, text)
  if not STATE.enabled then return end
  eventQueue[#eventQueue + 1] = {
    kind = tostring(kind or "event"),
    actor = tostring(actor or ""),
    text = tostring(text or ""),
  }
  while #eventQueue > 120 do
    table.remove(eventQueue, 1)
  end
end

local function flushEvents()
  if not STATE.enabled or #eventQueue == 0 then return end
  local rows = {}
  while #eventQueue > 0 and #rows < 40 do
    local event = table.remove(eventQueue, 1)
    rows[#rows + 1] = {
      server_id = CFG.serverUuid,
      kind = event.kind,
      actor = event.actor,
      text = event.text,
    }
  end
  call({
    method = "POST",
    path = "/activity",
    body = rows,
    onDone = function(status)
      if status < 200 or status >= 300 then dbg("activity flush failed (HTTP " .. tostring(status) .. ")") end
    end,
  })
end

-- ---------------------------------------------------------------
-- Server log tail (optional): forwards ERROR/WARNING lines to the panel
-- ---------------------------------------------------------------

local logPosition = nil

local function isLogConfigured()
  return type(CFG.logFile) == "string"
    and CFG.logFile ~= ""
    and not string.find(CFG.logFile, "<", 1, true)
end

local function tailLog()
  if not STATE.enabled or not isLogConfigured() then return end
  local file = fileOpen(CFG.logFile)
  if not file then return end

  local size = fileGetSize(file)
  if not logPosition then
    logPosition = size
    fileClose(file)
    return
  end
  if size < logPosition then
    logPosition = 0
  end
  if size == logPosition then
    fileClose(file)
    return
  end

  fileSetPos(file, logPosition)
  local chunk = fileRead(file, math.min(size - logPosition, 65536)) or ""
  logPosition = fileGetPos(file)
  fileClose(file)

  local pushed = 0
  for line in string.gmatch(chunk, "[^\r\n]+") do
    if pushed >= 20 then break end
    local low = string.lower(line)
    local level = nil
    if string.find(low, "error", 1, true) or string.find(low, "failed to load", 1, true)
      or string.find(low, "failed to start", 1, true) then
      level = "error"
    elseif string.find(low, "warning", 1, true) then
      level = "warn"
    end
    if level then
      rpAdminPushActivity(level, "server", string.sub(line, 1, 300))
      pushed = pushed + 1
    end
  end
end

-- ---------------------------------------------------------------
-- Lifecycle
-- ---------------------------------------------------------------

function rpAdminGetStatus()
  return STATE.online, STATE.lastSync, STATE.lastError
end

addEventHandler("onPlayerJoin", root, function()
  joinTimes[source] = getRealTime().timestamp
  local player = source
  setTimer(function()
    if isElement(player) and isStaffPlayer(player) then
      triggerClientEvent("rpAdmin:status", player, STATE.online, STATE.lastSync)
    end
  end, 2500, 1)
end)

addEventHandler("onPlayerQuit", root, function()
  joinTimes[source] = nil
end)

addEventHandler("onResourceStart", resourceRoot, function(started)
  if started ~= getThisResource() then return end
  if not configured() then
    log("shared/config.lua is not configured — the web panel connector is disabled")
    return
  end
  STATE.enabled = true
  log("connector started for server " .. tostring(CFG.serverId) .. " — polling " .. BASE .. " every " .. tostring(CFG.pollInterval or 3000) .. "ms")
  schedulePoll(500)
  setTimer(pushSnapshot, 1500, 1)
  setTimer(pushSnapshot, tonumber(CFG.snapshotInterval) or 20000, 0)
  setTimer(flushEvents, tonumber(CFG.eventFlushInterval) or 5000, 0)
  if isLogConfigured() then
    setTimer(tailLog, 1000, 1)
    setTimer(tailLog, tonumber(CFG.logTailInterval) or 5000, 0)
    log("server log tail enabled: " .. tostring(CFG.logFile))
  end
end)
